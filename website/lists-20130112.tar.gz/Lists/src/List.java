public class List {
  class Node {
    int val;
    Node next;

    <% lvars: v : val, xs : list val %>
    <% requires: "this"/V · `"next" >> `v <*> `Node_list `v `xs%>
    <% ensures: "r", "this"/V · `"next" >> `v <*> `Node_list `v `xs </\> "r"/V == `((length xs) + 1) %>
    public int nodeLength() {
      int res = 1; <% forward. %>
      Node n = this.next; <% forward. %> 
      <%forward.%>
      if (n != null) {
        <% unfold nodeLength_spec. %>
        <% sl_apply lst_ptr_not_null; triple_nf; destruct H; subst; simpl. %>
        int sum = n.nodeLength(); <%forward.%>
        res = sum + 1; <%forward.%>
        <% eval_rhs; rewrite Zpos_P_of_succ_nat; reflexivity. %>
      }
   	  return res; <% forward. %>
   	  <% (sl_rewrite lst_ptr_null); [ent_nf; subst; simpl; sl_auto| destruct v0; simpl in *; try reflexivity]. %>
	  <% destruct (natstring_DT.eq_dec p pnull); [assumption|intuition].%>
     }
  }
  Node head;
    		
  <% lvars: xs : list val %>
  <% requires: `List_rep "this"/V `xs %>
  <% ensures: "r", lift2 List_rep "this"/V `xs </\> "r"/V == `(length xs) %>
  public int length () {
    int r = 0; <% forward. %>
    Node start = this.head; <%forward. %>
    <% forward. %>
    <%unfold nodeLength_spec.%>
    <% sl_apply lst_ptr_not_null; triple_nf; destruct H; subst; simpl. %>
    if (start != null)
	  r = start.nodeLength(); <%forward.%>
      <% ent_nf; eval_rhs; rewrite Zpos_P_of_succ_nat; intuition; unfold Zsucc. %>
      <% rewrite inj_plus; simpl; reflexivity. %>
    return r; <% forward. %>
    <% (sl_rewrite lst_ptr_null); [ent_nf; subst; simpl; sl_auto | destruct x0; simpl in *; try reflexivity].%>
	<% destruct (natstring_DT.eq_dec p pnull); [assumption|intuition].%>
  }
    		  
 
  <% lvars: xs : list val %>
  <% requires: `List_rep "this"/V `xs %>
  <% ensures: `List_rep "this"/V (`cons "n"/V `xs) %>
  public void add (int n) {
    Node x = new Node(); <%forward. %>
    x.val = n; <% forward. %>
    Node tmp = head; <% forward. %>
    x.next = tmp; <% forward. %>
    this.head = x; <% forward. %>
    <% sl_simpl. %>
  }

  <% lvars: xs : list val %>
  <% requires: `List_rep "this"/V `xs %>
  <% ensures: `List_rep "this"/V `(rev xs) %>
  public void reverse () {
    Node old = null; <% forward. %>
    Node lst = this.head; <% forward. %>
    <% invariant: <E> ys, <E> zs, `Node_list "old"/V `ys <*> `Node_list "lst"/V `zs </\> <pure> `(v = ((rev ys) ++ zs)%list) </\> <pure>("this" ::: "List") frame: "this"/V · `"head" >> `x0 %>
    while (lst != null) {
      <% up_exists (@nil val); sl_simpl. %>
      <% destruct x3; [sl_contradict; congruence |]; triple_nf. %>
      Node tmp = lst.next; <% forward. %>
      lst.next = old; <% forward. %>
      old = lst; <% forward. %>
      lst = tmp; <% forward. %>
    }
    <% up_exists (s :: x2) x3. %>
    <% simpl; rewrite <- app_assoc; simpl. %>
    <% sl_simpl. %>
    this.head = old; <% forward. %>
    <% rewrite (@negb_false_iff _), pure_dec_eval_iff' in H0. %>
    <% rewrite (lst_ptr_null H0); sl_auto. %>
    <% rewrite app_nil_r, rev_involutive; sl_simpl. %>
  }

  
   
 
  
}