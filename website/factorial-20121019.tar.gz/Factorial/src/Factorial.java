
public class Factorial {

	<% lvars: x : val %> /* This one should not be necessary */
	<% requires: <pure>`("n"/V [>=] `0) %>
	<% ensures: "r", "r"/V == fac "n"/V %>
	public static int fac(int n) {
		int r = 1; <% forward. %>
	    <% forward. %>
		if (n > 0) {
			r = fac(n - 1); <% unfold fac_spec; forward; [omega|]. %>
			r = n * r; <% forward. %>
		}
		<%  rewrite facZ_step; [sl_simpl | assumption]. %>
		<% forward. %>
		<% assert (n = Z0) by intuition; eval_rhs; subst; intuition. %>
		return r; 
	}
	
}
